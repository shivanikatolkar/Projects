package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.IHotelDao;
import com.cg.model.HotelDetails;

/**
 * Author: Shivani Katolkar
 * 
 * Date: 28 July 2018
 * 
 * Class name: HotelServiceImpl.java
 * 
 * Number of methods : 1
 */

@Service("hotelService")
public class HotelServiceImpl implements IHotelService {

	@Autowired
	private IHotelDao hotelDao;  //dao layer object to access all method from dao layer
	
	@Override
	public List<HotelDetails> getHotels() {
		
		return hotelDao.getHotels();
	}

}
