package com.cg.service;

import java.util.List;

import com.cg.model.HotelDetails;

/**
 * Author: Shivani Katolkar
 * 
 * Date: 28 July 2018
 * 
 * Interface name: IHotelService.java
 * 
 */

public interface IHotelService {

	public List<HotelDetails> getHotels();

}
