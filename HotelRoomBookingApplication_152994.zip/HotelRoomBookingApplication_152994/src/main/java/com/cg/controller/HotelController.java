package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.model.HotelDetails;
import com.cg.service.IHotelService;
/**
 * Author: Shivani Katolkar
 * 
 * Date: 28 July 2018
 * 
 * Class name: HotelController.java
 * 
 * Number of methods : 3
 */

@Controller
public class HotelController {

	@Autowired
	private IHotelService hotelService;
	
	String hotelName;
	
	
	//requestMapping to home page(/) as HotelDetails.jsp(view to controller)
	@RequestMapping("/")
	public String showHotel(ModelMap map)
	{	
		List<HotelDetails> hotels = hotelService.getHotels();
		map.put("hotels", hotels);
		return "HotelDetails";
	}
	
	//requestMapping to HotelBooking.jsp for booking link
	@RequestMapping("/show/{name}")
	public String findHotel(@PathVariable("name") String name) {
		hotelName=name;
		return "HotelBooking";
		
	}
	
	//requestMapping to BookingConfirmation.jsp for confirmed booking status
	@RequestMapping("/show/success")
	public ModelAndView booking() {
		return new ModelAndView("BookingConfirmation","hotelName",hotelName);
		
	}
}
