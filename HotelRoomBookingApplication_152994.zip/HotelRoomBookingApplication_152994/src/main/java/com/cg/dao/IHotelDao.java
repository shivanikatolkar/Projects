package com.cg.dao;

import java.util.List;
import com.cg.model.HotelDetails;

/**
 * Author: Shivani Katolkar
 * 
 * Date: 28 July 2018
 * 
 * Interface name: IHotelDao.java
 *
 */

public interface IHotelDao {

	public List<HotelDetails> getHotels();
	
}
