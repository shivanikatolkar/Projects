package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.model.HotelDetails;

/**
 * Author: Shivani Katolkar
 * 
 * Date: 28 July 2018
 * 
 * Class name: HotelDaoImpl.java
 * 
 * Number of methods : 1
 */

@Repository("hotelDao")
@Transactional
public class HotelDaoImpl implements IHotelDao {

	@PersistenceContext
	private EntityManager em;
	
	@Override
	public List<HotelDetails> getHotels() {
		List<HotelDetails> hotels = em.createQuery("from HotelDetails").getResultList(); //for retrieving all the hotel details from Database
		return hotels;
	}

}
