package com.cg.walletjdbc.dao;

public interface QueryMapper {
	public static final String INSERT_QUERY_CUSTOMER="INSERT INTO customerDetails VALUES(customerDetails_sequence.NEXTVAL,?,?,?,?,?,?,?)";
	public static final String CUSTOMER_QUERY_SEQUENCE="SELECT customerDetails_sequence.CURRVAL FROM DUAL";
	public static final String GET_BALANCE_CUSTOMER ="SELECT balance FROM customerDetails WHERE accNumber = ?";
	public static final String INSERT_TRANSACTION="INSERT INTO transaction VALUES(transaction_sequence.NEXTVAL,?,?,?)";
	public static final String UPDATE_CUSTOMER_DEPOSIT="UPDATE customerDetails SET balance = balance + ? WHERE accNumber = ?";
	public static final String UPDATE_CUSTOMER_WITHDRAW="UPDATE customerDetails SET balance = balance - ? WHERE accNumber = ?";
	public static final String PRINT_TRANSACTION="SELECT transId, accNo, transAmt, transType WHERE accNumber = ?";
}


/******************TABLESCRIPT*******************
CREATE TABLE customerDetails(
accNumber NUMBER PRIMARY KEY,
name VARCHAR2(20),
mobile VARCHAR2(10),
email VARCHAR2(20),
address VARCHAR2(40),
accountType VARCHAR2(20),
balance NUMBER,
pin NUMBER
);

CREATE SEQUENCE customerDetails_sequence;


CREATE TABLE transaction
(
transId INT PRIMARY KEY,
accNumber NUMBER NOT NULL,
transAmt NUMBER NOT NULL,
transType CHAR(1) NOT NULL,
FOREIGN KEY(accNumber)
REFERENCES customerDetails(accNumber)
);

CREATE SEQUENCE transaction_sequence;
************************************************/