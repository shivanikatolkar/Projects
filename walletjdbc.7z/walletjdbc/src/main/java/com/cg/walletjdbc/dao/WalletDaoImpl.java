package com.cg.walletjdbc.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import com.cg.walletjdbc.bean.Customer;
import com.cg.walletjdbc.bean.Transaction;
import com.cg.walletjdbc.exception.WalletException;
import com.cg.walletjdbc.util.DBConnection;

public class WalletDaoImpl implements WalletDao {
	
	
Logger logger=Logger.getRootLogger();
	
	
	public WalletDaoImpl() {
		
		PropertyConfigurator.configure("resources//log4j.properties");
	}
	
	@SuppressWarnings("resource")
	@Override
	public long createAccount(Customer cust)  throws WalletException {
		
		Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		
		int queryResult=0;
		try
		{		
			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY_CUSTOMER);

			preparedStatement.setString(1,cust.getName());
			preparedStatement.setString(2,cust.getMobile());
			preparedStatement.setString(3,cust.getEmail());
			preparedStatement.setString(4,cust.getAddress());
			preparedStatement.setString(5,cust.getAccountType());
			preparedStatement.setDouble(6,cust.getBalance());
			preparedStatement.setInt(7,cust.getPin());
					
			queryResult=preparedStatement.executeUpdate();
			
			preparedStatement = connection.prepareStatement(QueryMapper.CUSTOMER_QUERY_SEQUENCE);
			
			
			return queryResult;
			
		 }
		catch(SQLException sqlException)
		{
			logger.error(sqlException.getMessage());
			sqlException.printStackTrace();
			throw new WalletException("Tehnical problem occured refer log");
		}
		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				logger.error(sqlException.getMessage());
				throw new WalletException("Error in closing db connection");	
			}
		}
	}
	@Override
	public long getBalance(long accNumber) throws WalletException {
	
		Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		
		ResultSet resultSet = null;

		try
		{		
			preparedStatement=connection.prepareStatement(QueryMapper.GET_BALANCE_CUSTOMER);

			preparedStatement.setLong(1,accNumber);
					
			resultSet=preparedStatement.executeQuery();
			resultSet.next();
			long result = (long) resultSet.getDouble("balance");
			return result;
		 }
		catch(SQLException sqlException)
		{
			logger.error(sqlException.getMessage());
			throw new WalletException("Tehnical problem occured refer log");
		}
		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				logger.error(sqlException.getMessage());
				throw new WalletException("Error in closing db connection");	
			}
		}
	}
	@SuppressWarnings("resource")
	@Override
	public boolean addDeposit(long num, double amt) throws WalletException {
		Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		int queryResult=0;
		try
		{	
			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_TRANSACTION);
			preparedStatement.setLong(1, num);
			preparedStatement.setDouble(2, amt);
			preparedStatement.setString(3, "D");
			queryResult=preparedStatement.executeUpdate();
			
			preparedStatement=connection.prepareStatement(QueryMapper.UPDATE_CUSTOMER_DEPOSIT);

			preparedStatement.setDouble(1, amt);
			preparedStatement.setLong(2, num);
			queryResult=preparedStatement.executeUpdate();
			return true;
		 }
		catch(SQLException sqlException)
		{
			logger.error(sqlException.getMessage());
			sqlException.printStackTrace();
			throw new WalletException("Tehnical problem occured refer log");
		}
		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				logger.error(sqlException.getMessage());
				throw new WalletException("Error in closing db connection");	
			}
		}
	}
	@Override
	public boolean withdrawAmount(long num, double amt) throws WalletException {
		Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
				int queryResult=0;
				try
				{	
					preparedStatement=connection.prepareStatement(QueryMapper.INSERT_TRANSACTION);
					preparedStatement.setLong(1, num);
					preparedStatement.setDouble(2, amt);
					preparedStatement.setString(3, "W");
					queryResult=preparedStatement.executeUpdate();
					
					
					preparedStatement=connection.prepareStatement(QueryMapper.UPDATE_CUSTOMER_WITHDRAW);
					preparedStatement.setDouble(1, amt);
					preparedStatement.setLong(2, num);
					queryResult=preparedStatement.executeUpdate();
					return true;
				 }
				catch(SQLException sqlException)
				{
					logger.error(sqlException.getMessage());
					sqlException.printStackTrace();
					throw new WalletException("Tehnical problem occured refer log");
				}
				finally
				{
					try 
					{
						preparedStatement.close();
						connection.close();
					}
					catch (SQLException sqlException) 
					{
						logger.error(sqlException.getMessage());
						throw new WalletException("Error in closing db connection");	
					}
				}
	}
	@Override
	public boolean fundTransfer(long num, long num1, double amt) throws WalletException {
Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
				int queryResult=0;
				try
				{	
					preparedStatement=connection.prepareStatement(QueryMapper.INSERT_TRANSACTION);
					preparedStatement.setLong(1, num1);
					preparedStatement.setDouble(2, amt);
					preparedStatement.setString(3, "D");
					queryResult=preparedStatement.executeUpdate();
					
					preparedStatement=connection.prepareStatement(QueryMapper.UPDATE_CUSTOMER_DEPOSIT);
					preparedStatement.setDouble(1, amt);
					preparedStatement.setLong(2, num1);
					queryResult=preparedStatement.executeUpdate();
				
					preparedStatement=connection.prepareStatement(QueryMapper.INSERT_TRANSACTION);
					preparedStatement.setLong(1, num);
					preparedStatement.setDouble(2, amt);
					preparedStatement.setString(3, "W");
					queryResult=preparedStatement.executeUpdate();
					
					preparedStatement=connection.prepareStatement(QueryMapper.UPDATE_CUSTOMER_WITHDRAW);
					preparedStatement.setDouble(1, amt);
					preparedStatement.setLong(2, num);
					queryResult=preparedStatement.executeUpdate();
					return true;
					}catch(SQLException sqlException)
					{
					logger.error(sqlException.getMessage());
					sqlException.printStackTrace();
					throw new WalletException("Tehnical problem occured refer log");
				}
				finally
				{
					try 
					{
						preparedStatement.close();
						connection.close();
					}
					catch (SQLException sqlException) 
					{
						logger.error(sqlException.getMessage());
						throw new WalletException("Error in closing db connection");	
					}
				}
	}
	@Override
	public boolean printTransaction(long num) throws WalletException {
Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		
		ResultSet resultSet = null;
		Transaction trans=new Transaction();
		try
		{		
			preparedStatement = connection.prepareStatement(QueryMapper.PRINT_TRANSACTION);

			preparedStatement.setLong(1, num);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {

			trans.setTransId(resultSet.getInt("transId"));
			trans.setAccNo(resultSet.getLong("accNo"));
			trans.setTransAmt(resultSet.getDouble("transAmt"));
			trans.setTransType(resultSet.getString("transType"));
			System.out.println(trans);
		 }
			return true;
		}
			
		catch(SQLException sqlException)
		{
			logger.error(sqlException.getMessage());
			throw new WalletException("Tehnical problem occured refer log");
		}
		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				logger.error(sqlException.getMessage());
				throw new WalletException("Error in closing db connection");	
			}
		}
}
}


