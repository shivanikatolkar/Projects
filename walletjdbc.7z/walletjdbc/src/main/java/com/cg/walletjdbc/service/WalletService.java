package com.cg.walletjdbc.service;

import com.cg.walletjdbc.bean.Customer;
import com.cg.walletjdbc.exception.WalletException;

public interface WalletService {
	long getBalance(long accNumber) throws WalletException;
	long createAccount(Customer cust)  throws WalletException;
	boolean addDeposit(long num,double amt) throws WalletException; 
	boolean validateCustomer(Customer cust) throws WalletException;
	boolean withdrawAmount(long num,double amt) throws WalletException; 
	boolean fundTransfer(long num,long num1,double amt) throws WalletException; 
	boolean printTransaction(long num) throws WalletException;
}
