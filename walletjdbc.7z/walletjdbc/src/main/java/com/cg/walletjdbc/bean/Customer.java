package com.cg.walletjdbc.bean;

public class Customer {
	private long accNumber;
	private String name;
	private String mobile;
	private String email;
	private String address;
	private String accountType;
	private double balance;
	private int pin;
	
	
	public Customer() {
		
	}
	public Customer(long accNumber, String name, String mobile, String email, String address, String accountType,
			double balance, int pin) {
		super();
		this.accNumber = accNumber;
		this.name = name;
		this.mobile = mobile;
		this.email = email;
		this.address = address;
		this.accountType = accountType;
		this.balance = balance;
		this.pin = pin;
		
	}
	public long getAccNumber() {
		return accNumber;
	}
	public void setAccNumber(int accNumber) {
		this.accNumber = accNumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public int getPin() {
		return pin;
	}
	public void setPin(int pin) {
		this.pin = pin;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	@Override
	public String toString() {
		return "Customer [accNumber=" + accNumber + ", name=" + name + ", mobile=" + mobile + ", email=" + email + ", address="
				+ address + ", balance="+balance+"]";
	}
}

