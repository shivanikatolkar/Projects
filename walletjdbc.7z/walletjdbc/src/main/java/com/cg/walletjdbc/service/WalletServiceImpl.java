package com.cg.walletjdbc.service;

import com.cg.walletjdbc.bean.Customer;
import com.cg.walletjdbc.dao.WalletDao;
import com.cg.walletjdbc.dao.WalletDaoImpl;
import com.cg.walletjdbc.exception.WalletException;

public class WalletServiceImpl implements WalletService {
WalletDao dao=new WalletDaoImpl();
	@Override
	public long getBalance(long accNumber) throws WalletException {
		
		return dao.getBalance(accNumber);
	}
	@Override
	public long createAccount(Customer cust) throws WalletException {
		
		return dao.createAccount(cust);
	}
	@Override
	public boolean validateCustomer(Customer cust) throws WalletException {
		if (validateName(cust.getName()) && validateMobile(cust.getMobile()) && validateEmail(cust.getEmail())
				&& validateAddress(cust.getAddress())) {
			return true;
		}
		return false;
	}
	private boolean validateName(String name) throws WalletException {
		if (name.isEmpty() || name == null) {
			throw new WalletException("Employee Name cannot be empty");
		} else {
			if (!name.matches("[A-Z][A-Za-z ]{2,}")) {
				throw new WalletException(
						"Name should start with a Capital letter followed by minimum of 2 alphabets");
			}
		}
		return true;
	}
	private boolean validateMobile(String mobile) throws WalletException {

		if (mobile.isEmpty() || mobile == null) {
			throw new WalletException("Mobile Number is mandatory");

		} else {
			if (!mobile.matches("\\d{10}")) {
				throw new WalletException("Mobile number should contain only 10 digits");
			}
		}
		return true;
	}
	
	private boolean validateEmail(String email) throws WalletException {
		if(!email.matches("[A-Za-z0-9_]+@+[a-z]+\\.com")) {
			throw new WalletException("Please enter a valid email Id");
		}
		return true;
	}
	
	private boolean validateAddress(String addr) throws WalletException {
		if(addr.isEmpty()||addr==null) {
			throw new WalletException("Address cannot be empty");
		}
		return true;
	}
	@Override
	public boolean addDeposit(long num, double amt) throws WalletException {
		
		return dao.addDeposit(num, amt);
	}
	@Override
	public boolean withdrawAmount(long num, double amt) throws WalletException {
	
		return dao.withdrawAmount(num,amt);
	}
	@Override
	public boolean fundTransfer(long num, long num1, double amt) throws WalletException {
		
		return dao.fundTransfer(num, num1, amt);
	}
	@Override
	public boolean printTransaction(long num) throws WalletException {
		
		return dao.printTransaction(num);
	}
	

}
