package com.cg.cab.dao;

import com.cg.cab.bean.CabRequest;
import com.cg.cab.exception.BookingException;

public interface BookingDao {
	public int addRequest(CabRequest request) throws BookingException;
	public CabRequest getRequest(int requestId) throws BookingException;
}
