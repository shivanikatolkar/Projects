package com.cg.cab.db;

import java.util.HashMap;

import com.cg.cab.bean.CabRequest;

public class BookingDB {
	private static HashMap<Integer,CabRequest> BookingMap=new HashMap<Integer,CabRequest>();

	public static HashMap<Integer, CabRequest> getBookingMap() {
		return BookingMap;
	}
	
}
