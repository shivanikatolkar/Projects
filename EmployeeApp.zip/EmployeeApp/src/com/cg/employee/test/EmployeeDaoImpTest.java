package com.cg.employee.test;

import static org.junit.Assert.*;

import java.util.Collection;

import org.junit.Test;

import com.cg.employee.bean.Employee;
import com.cg.employee.dao.EmployeeDao;
import com.cg.employee.dao.EmployeeDaoImp;
import com.cg.employee.exception.EmployeeException;

public class EmployeeDaoImpTest {
	EmployeeDao dao=new EmployeeDaoImp();
	
	@Test
	public void testGetAllEmployees() {
		try {
			Collection<Employee> employees=dao.getAllEmployees();
			assertEquals(6, employees.size());
		}catch(EmployeeException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testGetEmployeeById() {
		try {
			Employee emp=dao.getEmployeeById(1002);
			assertNotNull(emp);
			Employee emp1=dao.getEmployeeById(2000);
			assertNotNull(emp1);
			
		}catch(EmployeeException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testDeleteEmployee() {
		try {
			boolean b=dao.deleteEmployee(1001);
			assertTrue(b);
			
		}catch(EmployeeException e) {
			e.printStackTrace();
		}
	}

	@Test(expected=EmployeeException.class)
	public void testAddEmployee() {
		Employee emp=new Employee();
		emp.setId(1005);
		emp.setName("Chinnu");
		emp.setMobile("9999999999");
		emp.setEmail("abc@xtz.com");
		emp.setSalary(50000);
		try {
			dao.addEmployee(emp);
		}catch(EmployeeException e) {
			e.printStackTrace();
		}
	
	}

}
