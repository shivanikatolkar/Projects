 package com.cg.employee.ui;

import java.util.Collection;
import java.util.List;
import java.util.Scanner;

import com.cg.employee.bean.Employee;
import com.cg.employee.exception.EmployeeException;
import com.cg.employee.service.EmployeeService;
import com.cg.employee.service.EmployeeServiceImpl;

public class Client {
	EmployeeService employeeService=new EmployeeServiceImpl();
	Scanner scan=new Scanner(System.in);
	public static void main(String[] args) {
		String option=null;
		
		Client c=new Client();
		 while(true) {
			 System.out.println("=======Employee Management System=======");
			 System.out.println("1. Add an Employee");
			 System.out.println("2. Display all Employees");
			 System.out.println("3. Display an Employee");
			 System.out.println("4. Delete an Employee");
			 System.out.println("5. Update an Employee");
			 System.out.println("6. Exit");
			 System.out.println("7. View Employee Based on Salary");
			 System.out.println("Choose an option");
			 option=c.scan.nextLine();
			 
			 switch(option) {
			 case "1":
				 c.addEmployee();
				 break;
			 case "2":
				c.getAllEmployee();
				 break;
			 case "3":
				 c.getEmployeebyId();
				 break;
			 case "4":
				 c.deleteEmployee();
				 break;
			 case "5":
				 c.updateEmployee();
				 break;
			 case "6":
				 System.exit(0);
		     default:
		    	 System.err.println("Invalid option choose from 1-6");
		    	 break;
		     case "7":
		    	 c.getEmployeeBySalary();
		    	 break;
			 }
		 }
	}
	public void getAllEmployee() {
		try {
			Collection<Employee> employees=employeeService.getAllEmployees();
			/*employees.forEach(System.out::println);*/
			employees.stream().sorted((x,y)->x.getSalary()>y.getSalary()?1:x.getSalary()<y.getSalary()?-1:0).
			forEach(System.out::println);  //if the question says sort in some order
		} catch (EmployeeException e) {
			System.err.println("An Error Occured "+e.getMessage());
		}
	}
	public void getEmployeebyId() {
		System.out.println("Enter Employee Id");
		String id=scan.nextLine();
		try {
		int empId=Integer.parseInt(id);
			Employee emp=employeeService.getEmployeeById(empId);
			System.out.println(emp);
		} catch (EmployeeException e) {
			System.err.println("An Error Occured"+e.getMessage());
		}
	}
	public void deleteEmployee() {
		System.out.println("Enter Employee Id");
		String id=scan.nextLine();
		try {
			int empId=Integer.parseInt(id);
			boolean result=employeeService.deleteEmployee(empId);
			if(result) {
				System.out.println("Employee with Id " +empId+" Successfully deleted");
			}
		}
		catch (EmployeeException ex) {
			System.err.println("An Error Occured"+ex.getMessage());
		}
		}
		public void addEmployee() {
			Employee emp=new Employee();
			System.out.println("Enter Employee Id");
			/*String id=scan.nextLine();
			int empId=Integer.parseInt(id);
			emp.setId(empId);*/
			emp.setId(Integer.parseInt(scan.nextLine())); //same thing written in single line
			System.out.println("Enter Employee Name");
			emp.setName(scan.nextLine());
			System.out.println("Enter Mobile");
			emp.setMobile(scan.nextLine());
			System.out.println("Enter Email");
			emp.setEmail(scan.nextLine());
			System.out.println("Enter Salary");
			emp.setSalary(Double.parseDouble(scan.nextLine()));
			try {
				boolean result=employeeService.validateEmployee(emp);
				if(result) {
					int ret=employeeService.addEmployee(emp);
					System.out.println("Employee with id "+ret+" added successfully");
				}
			}
			catch (EmployeeException ex) {
				System.out.println();
				System.err.println("An Error Occured "+ex.getMessage());
				System.out.println();
			}
		}
		
		//new addition
		public void getEmployeeBySalary() {
			System.out.println("Enter Salary");
			try {
			double salary=Double.parseDouble(scan.nextLine());
			Collection <Employee> employees=employeeService.getEmployeeBySalary(salary);
			//employees.stream().forEach(System.out::println);
			employees.forEach(System.out::println);
		}
			catch(EmployeeException e){
				System.out.println();
				System.err.println("An Error Occured "+e.getMessage());
				System.out.println();
			}
			catch(Exception e) {
				System.out.println();
				System.err.println("An Error Occured "+e.getMessage());
				System.out.println();
			}
	}
		
		public void updateEmployee() {
			Employee emp=new Employee();
			System.out.println("Enter Employee Id");
			emp.setId(Integer.parseInt(scan.nextLine())); //same thing written in single line
			System.out.println("Enter Employee Name");
			emp.setName(scan.nextLine());
			System.out.println("Enter Mobile");
			emp.setMobile(scan.nextLine());
			System.out.println("Enter Email");
			emp.setEmail(scan.nextLine());
			System.out.println("Enter Salary");
			emp.setSalary(Double.parseDouble(scan.nextLine()));
			try {
				boolean result=employeeService.validateEmployee(emp);
				if(result) {
					int ret=employeeService.updateEmployee(emp);
					System.out.println("Employee with id "+ret+" updated successfully");
				}
			}
			catch (EmployeeException ex) {
				System.out.println();
				System.err.println("An Error Occured "+ex.getMessage());
				System.out.println();
			}
		}
	}


