package com.wallet.dao;

import java.util.HashMap;
import java.util.Optional;
import java.util.Scanner;
import com.wallet.DB.AccountDB;
import com.wallet.bean.Customer;
import com.wallet.exception.WalletException;

public class WalletDaoImpl implements WalletDao {
	Scanner scan = new Scanner(System.in);
	static HashMap<Integer, Customer> custMap = AccountDB.getCustMap();

	@Override
	public Customer getBalance(int accNumber) throws WalletException {
		try {
			Customer customers = custMap.get(accNumber);

			if (customers == null) {
				throw new WalletException("Employee with Id:" + accNumber + "Not available in the database");
			}
			return customers;
		} catch (Exception ex) {
			throw new WalletException(ex.getMessage());
		}
	}

	@Override
	public int createAccount(Customer cust) throws WalletException {

		try {
			if (custMap.size() == 0) {
				cust.setAccNumber(7678);
			} else {
				Optional<Integer> id = custMap.keySet().stream().max((x,y)->(x>y)?1:(x<y)?-1:0);
				int reqId = id.get() + 1;
				cust.setAccNumber(reqId);
			}
			custMap.put(cust.getAccNumber(), cust);
			return cust.getAccNumber();
		} catch (Exception ex) {
			throw new WalletException(ex.getMessage());
		}

	}

	@Override
	public boolean addDeposit(int num, double amt) throws WalletException {

		try {
			Customer c = custMap.get(num);

			if (c == null) {
				throw new WalletException("Invalid id");

			} else {
				double amount1 = custMap.get(num).getBalance();
				amount1 = amount1 + amt;
				c.setBalance(amount1);
				c.setTransaction("Amount " + amt + " credited to account " + num);
				custMap.replace(c.getAccNumber(), c);
			}
		} catch (WalletException e) {
			throw new WalletException(e.getMessage());
		}
		return true;
	}

	@Override
	public boolean withdrawAmount(int num, double amt) throws WalletException {
		try {
			Customer c = custMap.get(num);

			if (c == null) {
				throw new WalletException("Invalid id");

			} else {
				double amount1 = custMap.get(num).getBalance();
				amount1 = amount1 - amt;
				c.setBalance(amount1);
				c.setTransaction("Amount " + amt + " withdrawn from your account " + num);
				custMap.replace(c.getAccNumber(), c);
			}
		} catch (WalletException e) {
			throw new WalletException(e.getMessage());
		}
		return true;
	}

	@Override
	public boolean fundTransfer(int num, int num1, double amt) throws WalletException {
		try {
			Customer c = custMap.get(num1);

			if (c == null) {
				throw new WalletException("Invalid id");

			} else {
				double amt1 = custMap.get(num1).getBalance();
				amt1 = amt1 + amt;
				c.setBalance(amt1);
				c.setTransaction("Amount " + amt + " credited to account " + num);

				custMap.replace(c.getAccNumber(), c);
			}
			Customer c1 = custMap.get(num);

			if (c1 == null) {
				throw new WalletException("Invalid id");

			} else {
				double amount1 = custMap.get(num).getBalance();
				amount1 = amount1 - amt;
				c1.setBalance(amount1);
				c1.setTransaction("Amount " + amt + " withdrawn from your account " + num
						+ " and transfered to account " + num1);
				custMap.replace(c1.getAccNumber(), c1);
			}
		} catch (WalletException e) {
			throw new WalletException(e.getMessage());
		}
		return true;
	}

	@Override
	public String printTransaction(int num) throws WalletException {
		try {
			Customer c1 = custMap.get(num);

			if (c1 == null) {
				throw new WalletException("Employee with Id:" + num + "Not available in the database");
			}
			return c1.getTransaction();
		} catch (WalletException ex) {
			throw new WalletException(ex.getMessage());
		}
	}
}
