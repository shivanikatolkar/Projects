package com.wallet.dao;

import com.wallet.bean.Customer;
import com.wallet.exception.WalletException;

public interface WalletDao {

Customer getBalance(int accNumber) throws WalletException;
int createAccount(Customer cust)  throws WalletException;
boolean addDeposit(int num,double amt) throws WalletException; 
boolean withdrawAmount(int num,double amt) throws WalletException; 
boolean fundTransfer(int num,int num1,double amt) throws WalletException; 
String printTransaction(int num) throws WalletException;
}
