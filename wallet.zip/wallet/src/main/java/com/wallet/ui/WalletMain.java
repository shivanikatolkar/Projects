package com.wallet.ui;

import java.util.HashMap;
import java.util.Scanner;
import com.wallet.DB.AccountDB;
import com.wallet.bean.Customer;
import com.wallet.exception.WalletException;
import com.wallet.service.WalletService;
import com.wallet.service.WalletServiceImpl;

public class WalletMain {
	static HashMap<Integer, Customer> custMap = AccountDB.getCustMap();
	WalletService walletService = new WalletServiceImpl();
	Scanner scan = new Scanner(System.in);

	public static void main(String[] args) {
		String options = null;
		WalletMain wm = new WalletMain();
		while (true) {
			System.out.println("========Payment Display Menu========");
			System.out.println();
			System.out.println("1. Create Account ");
			System.out.println("2. Show Balance ");
			System.out.println("3. Deposit ");
			System.out.println("4. Withdraw ");
			System.out.println("5. Fund Transfer");
			System.out.println("6. Print Transactions");
			System.out.println("7. Exit");
			System.out.println();
			System.out.println("Choose an option");
			options = wm.scan.nextLine();
			switch (options) {
			case "1":
				wm.createAccount();
				break;
			case "2":
				wm.getBalance();
				break;
			case "3":
				wm.addDeposit();
				break;
			case "4":
				wm.withdrawAmount();
				break;
			case "5":
				wm.fundTransfer();
				break;
			case "6":
				wm.printTransaction();
				break;
			case "7":
				System.exit(0);
				break;
			default:
				System.err.println("Invalid Option Choose from 1 to 7");
				System.out.println();
				break;
			}
		}
	}
	void createAccount() {
		Customer cust = new Customer();
		System.out.println("Enter full name : ");
		cust.setName(scan.nextLine());
		System.out.println("Enter mobile number : ");
		cust.setMobile(scan.nextLine());
		System.out.println("Enter email Id : ");
		cust.setEmail(scan.nextLine());
		System.out.println("Enter address : ");
		cust.setAddress(scan.nextLine());
		System.out.println("What type of account you want to create? (Savings/Current)");
    	cust.setAccountType(scan.nextLine());
		
		try {
			boolean result = walletService.validateCustomer(cust);
			if (result) {
				int ret = walletService.createAccount(cust);
				System.out.println("Your Account was created Successfully. Your Customer Id is "+ ret );
				System.out.println();
				System.out.println("Set your Pin number: ");
				cust.setPin(Integer.parseInt(scan.nextLine()));
				System.out.println();
				System.out.println("Your pin was set successfully. ");
			}
		} catch (WalletException e) {
			System.out.println();
			System.err.println("An error occured" + e.getMessage());
			System.out.println();
		}
	}
	void getBalance() {
		System.out.println("Enter Customer Id to view the balance  : ");
		int number = Integer.parseInt(scan.nextLine());
		System.out.println("Enter pin");
		int pin = Integer.parseInt(scan.nextLine());
		try {
			int pin1 = custMap.get(number).getPin();
			if (pin == pin1) {
				Customer cust = walletService.getBalance(number);
				System.out.println("The Availabe Balance is " +cust.getBalance());
			} else
				System.out.println("Invalid Pin Number");
		} catch (WalletException e) {
			System.err.println("An error occured" + e.getMessage());
		}
	}
	void addDeposit() {
		System.out.println("Enter Customer Id to deposit amount : ");
		int num = Integer.parseInt(scan.nextLine());
		System.out.println("Enter Pin Number");
		int pin = Integer.parseInt(scan.nextLine());
		try {
			int pin1 = custMap.get(num).getPin();
			if (pin == pin1) {

				System.out.println("Enter deposit amount");
				double amt = Double.parseDouble(scan.nextLine());

				boolean res = walletService.addDeposit(num, amt);
				if (res) {
					System.out.println("Amount of "+amt+" deposited in the Account having Customer Id " + num );
				} else
					System.out.println("Invalid");
			} else
				System.out.println("Invalid Pin Number");
		} catch (WalletException e) {
			System.err.println("An Error Occured " + e.getMessage());
			System.out.println();
		}
	}
	void withdrawAmount() {
		System.out.println("Enter Customer Id");
		int num = Integer.parseInt(scan.nextLine());
		System.out.println("Enter pin");
		int pin = Integer.parseInt(scan.nextLine());
		try {
			int pin1 = custMap.get(num).getPin();
			if (pin == pin1) {

				System.out.println("Enter amount to withdraw");
				double amt = Double.parseDouble(scan.nextLine());

				boolean res = walletService.withdrawAmount(num, amt);
				if (res) {
					System.out.println("Successfully withdrawn amount of "+amt+" from Customer Id " + num);
				} else
					System.out.println("Invalid");
			} else
				System.out.println("Invalid pin ");
		} catch (WalletException e) {
			System.err.println("An Error Occured " + e.getMessage());
			System.out.println();
		}
	}
	void fundTransfer() {
		System.out.println("Enter Customer Id:");
		int num = Integer.parseInt(scan.nextLine());
		System.out.println("Enter pin");
		int pin = Integer.parseInt(scan.nextLine());
		System.out.println("Enter destination Customer Id:");
		int num1 = Integer.parseInt(scan.nextLine());
		try {
			int pin1 = custMap.get(num).getPin();
			if (pin == pin1) {

				System.out.println("Enter amount to transfer");
				double amt = Double.parseDouble(scan.nextLine());

				boolean res = walletService.fundTransfer(num, num1, amt);
				if (res) {
					System.out.println("Successfully transfered amount of "+amt+" from customer "+num+" to customer "+num1);
				} else
					System.out.println("Invalid");
			} else
				System.out.println("Invalid pin ");
		} catch (WalletException e) {
			System.err.println("An Error Occured " + e.getMessage());
			System.out.println();
		}
	}
	void printTransaction() {
		System.out.println("Enter Customer Id:");
		int num = Integer.parseInt(scan.nextLine());
		System.out.println("Enter pin");
		int pin = Integer.parseInt(scan.nextLine());
		try {
			int pin1 = custMap.get(num).getPin();
			if (pin == pin1) {
				System.out.println("Transaction statement:");
			String s=walletService.printTransaction(num);
			System.out.println();
			System.out.println(s);
			System.out.println();
			}
			else
				System.out.println("invalid pin");
		}
		catch (WalletException e) {
			System.err.println("An Error Occured " + e.getMessage());
			System.out.println();
		}
	}
}
