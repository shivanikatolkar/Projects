package com.wallet.DB;

import java.util.HashMap;

import com.wallet.bean.Customer;

public class AccountDB {
private static HashMap<Integer,Customer> custMap=new HashMap<Integer,Customer>();
static {
	custMap.put(1001, new Customer(1001,"Shivani","8957652315","shivani@gmail.com","Nagpur","Savings",20000,1234,null));
	custMap.put(1002, new Customer(1002,"Mark","6548956235","mark@outlook.com","Bangalore","Savings",1500000,1458,null));
	custMap.put(1003, new Customer(1003,"Ankit","9999958585","anki@ymail.com","Chennai","Current",65000,6897,null));
	custMap.put(1004, new Customer(1004,"Mayuri","9988774455","mayu@gmail.com","Hyderbad","Savings",80000,3574,null));
	custMap.put(1005, new Customer(1005,"Kalyani","7777754878","kalyani@gmail.com","Mumbai","Current",200000,9687,null));
	custMap.put(1006, new Customer(1006,"Suraj","8989898989","suraj@gmail.com","Pune","Current",98000,3257,null));
}

public static HashMap<Integer,Customer> getCustMap(){
	return custMap;
}
}
